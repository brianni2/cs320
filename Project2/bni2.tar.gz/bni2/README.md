bni2
B00784511
Set associative with no allocation, prefetching, and prefetch-on-miss, and fully associative hot-cold are off by a small amount. I have tried everything I could think of and what I have now is the closest I could get to the expected output.