bni2
B00784511
Full-associative hot-cold does not work.
All of the functions except direct map are off by a small amount. I have tried everything I could think of and what I have now is the closest I could get to the expected output.